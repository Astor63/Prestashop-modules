<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{solditems}prestashop>solditems_d4fd7635cd5a92dd744ae5ccc853e35d'] = 'Sprzedanych przedmiotów';
$_MODULE['<{solditems}prestashop>solditems_40b03a205f85aae1e7f7351b9b367284'] = 'Pokazuje sprzedanych ilości produktu - www.catalogo-onlinersi.com.ar';
$_MODULE['<{solditems}prestashop>solditems_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{solditems}prestashop>solditems_da15f26e93917c69ad5b6da1249df8d3'] = 'Pokaż przedmioty solded więcej niż:';
$_MODULE['<{solditems}prestashop>solditems_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{solditems}prestashop>solditems_3576ed26d17b566642647c100113f6f1'] = 'Ten przedmiot został sprzedany';
$_MODULE['<{solditems}prestashop>solditems_f2b798f672d4b42c0359ced11d4f10cd'] = 'razy';
