<tr>
						<td class="col-left">Size</td>
						<td style="padding-bottom:5px;">
							<p>
							  <input size="6" maxlength="6" name="weight" type="text" value="" /> 
					    </p>
						<p>ñññññññññññññññ</p></td>
					</tr>
                    
             