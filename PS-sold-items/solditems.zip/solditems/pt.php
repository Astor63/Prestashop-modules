<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{solditems}prestashop>infos_86d25b8026725cd8e9658fb01bf3194a'] = 'Para uma versão completa deste módulo, com auto instalação e confirmação quando o cliente efetuar o pagamento, verifique WesterUnion +:';
$_MODULE['<{solditems}prestashop>solditems_d4fd7635cd5a92dd744ae5ccc853e35d'] = 'Itens vendidos';
$_MODULE['<{solditems}prestashop>solditems_40b03a205f85aae1e7f7351b9b367284'] = 'Mostra a quantidade vendida de um produto - www.catalogo-onlinersi.com.ar';
$_MODULE['<{solditems}prestashop>solditems_c888438d14855d7d96a2724ee9c306bd'] = 'Configurações atualizadas';
$_MODULE['<{solditems}prestashop>solditems_f4f70727dc34561dfde1a3c529b6205c'] = 'Configurações';
$_MODULE['<{solditems}prestashop>solditems_da15f26e93917c69ad5b6da1249df8d3'] = 'Ver itens vendidos, mais de:';
$_MODULE['<{solditems}prestashop>solditems_e73348cee6e9b3ce6ef3333af4ecb94b'] = 'Estilo de imagem:';
$_MODULE['<{solditems}prestashop>solditems_c4ca4238a0b923820dcc509a6f75849b'] = '1';
$_MODULE['<{solditems}prestashop>solditems_c81e728d9d4c2f636f067f89cc14862c'] = '2';
$_MODULE['<{solditems}prestashop>solditems_eccbc87e4b5ce2fe28308fd9f2a7baf3'] = '3';
$_MODULE['<{solditems}prestashop>solditems_a87ff679a2f3e71d9181a67b7542122c'] = '4';
$_MODULE['<{solditems}prestashop>solditems_e4da3b7fbbce2345d7772b0674a318d5'] = '5';
$_MODULE['<{solditems}prestashop>solditems_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar ';
$_MODULE['<{solditems}prestashop>solditems_9887a4451812854f0f1b6f669a874307'] = 'Contribuir';
$_MODULE['<{solditems}prestashop>solditems_e8928d746f7cf273fa76aabf3f906216'] = 'Você pode contribuir com uma doação, se os nossos módulos livres e temas são úteis para você. Clic no link e nos apoiar!';
$_MODULE['<{solditems}prestashop>solditems_4ad5cd8425d9ac520903c1819517f0e1'] = 'Para mais módulos e temas visite: www.catalogo-onlinersi.com.ar';
$_MODULE['<{solditems}prestashop>solditems_254f642527b45bc260048e30704edb39'] = 'Configuração';
$_MODULE['<{solditems}prestashop>solditems_52898b080e886d440c6244f0bbe6be9f'] = 'ID de status de ordem';
$_MODULE['<{solditems}prestashop>solditems_8ff86705ea42bdb6028f78790b404b86'] = 'Status do pedido (será preenchido automaticamente)';
$_MODULE['<{solditems}prestashop>solditems_ddebde5253c8c1da051b3cd822bbf467'] = 'Leia o README para obter este número de identificação';
$_MODULE['<{solditems}prestashop>solditems_ebf3d9d42804d691d712f778ea57f53b'] = 'Tipo de imagem';
$_MODULE['<{solditems}prestashop>solditems_b17f3f4dcf653a5776792498a9b44d6a'] = 'Configurações de atualização';
$_MODULE['<{solditems}prestashop>solditems_3576ed26d17b566642647c100113f6f1'] = 'Este produto foi vendido';
$_MODULE['<{solditems}prestashop>solditems_f2b798f672d4b42c0359ced11d4f10cd'] = 'Vezes';
