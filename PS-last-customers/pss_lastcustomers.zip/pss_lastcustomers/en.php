<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pss_slideshowpro}prestashop>pss_slideshowpro_160b153485f420fe11c47b8fc39c1727'] = 'http://www.prestascope.com/lang-en/content/10-module-slide-show-pro-installation';
