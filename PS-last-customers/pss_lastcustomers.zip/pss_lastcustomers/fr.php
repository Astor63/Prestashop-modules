<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_bbc217f0c474c22c4e59c80aebe49e9f'] = 'PSS / Bloc derniers clients';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_97de3c5e0d3747791c2a74612c1beebb'] = 'Affiche un bloc qui liste les derniers clients';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_314b7f328e7e1ebc197427c6bf610c40'] = 'Bloc des derniers clients';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_afc14375dc3cb57e6727ae4f7a2cafd6'] = 'Le nombre de clients doit être un nombre entier';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_d570715c3bf2cd1cea759f25eed154e9'] = 'Le modèle de ligne ne doit pas être vide';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_d4bc72be9854ed72e4a1da1509021bf4'] = 'Paramètres du bloc';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_7a1cc0cd216268e16060f2286198cf92'] = 'Nombre de clients';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_7347b59026389c42f49ad8734c02efa0'] = 'Le nombre de clients apparaissant dans le bloc';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_173c20d94b0f93b5beb85ebf8b915efb'] = 'Modèle de ligne';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_7a114d23a7b7c434e347a2344e311c4e'] = 'Chaque ligne est construite selon ce modèle. Vous pouvez utiliser des caractères constants, des balises HTML ou les codes de champs suivants :';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_29185b936f0c02555e9b5d108c35454b'] = '$last_name $first_name $country_name $postal_code $state_name $city_name';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_f3d1c94f56f147da2dc8c04b9ff3b3d7'] = '$last_name n\'affichera que la 1ère lettre majuscule du nom suivie d\'un point';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_01ef728a05a732e3591a42c67e86dcb6'] = 'Drapeaux des pays';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_d85c9d37be8ca3b1fea2a02b9047138c'] = 'afficher les drapeaux';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_fa5778c4dba71218eb3e8fbe1237f19a'] = 'Mettre à jour';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_19f823c6453c2b1ffd09cb715214813d'] = 'Champs obligatoires';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_4665d7023484b9a11192be049f713bc9'] = 'Nouvelles de Prestascope';
$_MODULE['<{pss_lastcustomers}prestashop>pss_lastcustomers_1a9c46c5de112e3cb217e0ec5576d499'] = 'Derniers clients';
